#!/bin/bash

#================================================================================================
# SKRIP BACKUP DATA
#================================================================================================

source "$(dirname "$0")/config.sh"

check_root

SPINNER_PID=""
start_spinner() {
    local -a frames=("⠋" "⠙" "⠹" "⠸" "⠼" "⠴" "⠦" "⠧" "⠇" "⠏")
    local i=0
    while true; do
        printf "\r  \033[96m%s\033[0m \033[90mMohon tunggu...\033[0m" "${frames[i++ % ${#frames[@]}]}"
        sleep 0.08
    done &
    SPINNER_PID=$!
    trap "kill \$SPINNER_PID > /dev/null 2>&1; printf '\r\033[K'" EXIT
}

stop_spinner() {
    if [ -n "$SPINNER_PID" ]; then
        kill "$SPINNER_PID" > /dev/null 2>&1
        wait "$SPINNER_PID" 2>/dev/null
        printf "\r\033[K"
        SPINNER_PID=""
    fi
    trap - EXIT
}


backup_data() {
    clear
    if ! command -v rclone &> /dev/null; then
        echo -e "${RED}rclone tidak terinstal. Fitur ini tidak tersedia.${NC}"; return
    fi
    
    setup_rclone || { echo -e "${RED}Setup Rclone dibatalkan.${NC}"; exit 1; }
    
    source "$RCLONE_CONF"

    local domain
    domain=$(cat "$DOMAIN_FILE")
    local backup_filename="backup-${domain}-$(date +%Y-%m-%d_%H-%M-%S).tar.gz"
    local backup_source="/etc/xray"
    local tmp_backup_path="/tmp/${backup_filename}"

    echo -e "${GREEN}--- Memulai Proses Backup ---${NC}"
    echo "Data yang akan di-backup: Direktori $backup_source"
    echo "Target: $RCLONE_REMOTE:$RCLONE_PATH/$backup_filename"
    echo ""
    echo "Membuat arsip..."
    start_spinner
    if ! tar -czf "$tmp_backup_path" -C "$(dirname "$backup_source")" "$(basename "$backup_source")" &>/dev/null; then
        stop_spinner
        echo -e "${RED}Gagal membuat arsip backup!${NC}"; rm -f "$tmp_backup_path"; return
    fi
    stop_spinner
    echo -e "${GREEN}✓ Arsip berhasil dibuat.${NC}"

    echo "Mengunggah ke remote..."
    start_spinner
    if ! rclone copy "$tmp_backup_path" "$RCLONE_REMOTE:$RCLONE_PATH/" &>/dev/null; then
        stop_spinner
        echo -e "${RED}Gagal mengunggah file backup ke rclone remote!${NC}"; rm -f "$tmp_backup_path"; return
    fi
    stop_spinner
    echo -e "${GREEN}✓ File backup berhasil diunggah.${NC}"

    rm -f "$tmp_backup_path"
    echo -e "${GREEN}Backup berhasil diselesaikan!${NC}"
}

backup_data