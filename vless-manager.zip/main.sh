#!/bin/bash
#================================================================================================
# SKRIP MANAJEMEN VPN VLESS (Versi Final Stabil)
# Perintah akses: menu
# Dibuat Oleh A2OS (Dimodifikasi untuk VLESS)
#================================================================================================

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
  DIR="$( cd -P "$( dirname "$SOURCE" )" &> /dev/null && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_REAL_DIR="$( cd -P "$( dirname "$SOURCE" )" &> /dev/null && pwd )"
source "$SCRIPT_REAL_DIR/config.sh"

SPINNER_PID=""
start_spinner() {
    local i=1
    local sp="/-\|"
    echo -n "  "
    while true; do
        printf "\b%c" "${sp:i++%${#sp}:1}"
        sleep 0.1
    done &
    SPINNER_PID=$!
    trap "kill $SPINNER_PID > /dev/null 2>&1" EXIT
}

stop_spinner() {
    if [ -n "$SPINNER_PID" ]; then
        kill "$SPINNER_PID" > /dev/null 2>&1
        wait "$SPINNER_PID" 2>/dev/null
        echo -e "\b "
        SPINNER_PID=""
    fi
    trap - EXIT
}

add_user() {
    clear
    echo -e "${GREEN}==================[ MENAMBAHKAN AKUN BARU ]==================${NC}"
    echo -e "${YELLOW}PERINGATAN: Pastikan Nama Pengguna unik untuk setiap akun!${NC}"
    read -p "Nama Pengguna (akan menjadi basis UUID): " username
    read -p "Masa aktif (hari, 0 untuk unlimited): " duration

    if [[ -z "$username" ]] || ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Input tidak valid!${NC}"
        return
    fi
    
    # --- BLOK MODIFIKASI: Membuat UUID dari Username ---
    local md5_hash=$(echo -n "$username" | md5sum | cut -d' ' -f1)
    local uuid="${md5_hash:0:8}-${md5_hash:8:4}-${md5_hash:12:4}-${md5_hash:16:4}-${md5_hash:20:12}"
    echo -e "${YELLOW}UUID yang dihasilkan untuk '${username}': ${uuid}${NC}"
    # --- AKHIR BLOK MODIFIKASI ---

    local exp_date
    local exp_message
    if [[ "$duration" == "0" ]]; then
        exp_date="9999-12-31"
        exp_message="Masa aktif: Selamanya"
    else
        exp_date=$(date -d "+$duration days" +"%Y-%m-%d")
        exp_message="Masa aktif hingga: $exp_date"
    fi

    echo "$username|$uuid|$exp_date|active" >> "$USER_DB"
    regenerate_config

    local domain=$(cat "$DOMAIN_FILE")

    echo -e "${GREEN}✓ Pengguna berhasil ditambahkan!${NC}"
    
    echo ""
    echo -e "${GREEN}=============================================================${NC}"
    echo ""
cat << EOF
- name: ${username}
  server: ${domain}
  port: 443
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vlessws
    headers:
      Host: ${domain}
  udp: true
EOF
    echo ""
    echo -e "${GREEN}=============================================================${NC}"
    echo ""
    echo "$exp_message"
    echo ""
}

delete_user() {
    clear
    echo -e "${GREEN}=======================[ HAPUS AKUN ]========================${NC}"
    echo ""
    if [ ! -s "$USER_DB" ]; then
        echo -e "${RED}Tidak ada pengguna.${NC}"
        return
    fi
    mapfile -t users < "$USER_DB"
    
    printf "%-4s %-20s %-15s %-15s %-10s\n" "No." "Nama Pengguna" "Hingga" "Sisa" "Status"
	echo -e "${GREEN}=============================================================${NC}"
    
    i=1
    for user_line in "${users[@]}"; do
        username=$(echo "$user_line"|cut -d'|' -f1)
        exp_date=$(echo "$user_line"|cut -d'|' -f3)
        status=$(echo "$user_line"|cut -d'|' -f4)
        [ -z "$status" ] && status="active"

        local color=$GREEN
        if [[ "$status" != "active" ]]; then
            color=$RED
        fi
        
        local sisa_hari_display
        local exp_date_display
        if [[ "$exp_date" == "9999-12-31" ]]; then
            sisa_hari_display="Selamanya"
            exp_date_display="Selamanya"
        else
            sisa_hari_display="$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 )) hari"
            exp_date_display="$exp_date"
        fi
        
        printf "${color}%-4s %-20s %-15s %-15s %-10s${NC}\n" "$i." "$username" "$exp_date_display" "$sisa_hari_display" "$status"
        ((i++))
    done
	echo -e "${GREEN}=============================================================${NC}"
    echo ""

    read -p "Pilih Nomor Pengguna yang akan dihapus permanen: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"
        return
    fi

    local user_to_delete=$(echo "${users[$((user_num-1))]}" | cut -d'|' -f1)

    echo ""
    echo -en "Apakah Anda yakin ingin menghapus akun ${GREEN}${user_to_delete}${NC} secara PERMANEN? (y/n): "
    read confirm
    
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        local line_status=$(echo "${users[$((user_num-1))]}" | cut -d'|' -f4)
        sed -i "${user_num}d" "$USER_DB"
        if [[ "$line_status" == "active" || -z "$line_status" ]]; then
            regenerate_config
        fi
        echo ""
        echo -e "${GREEN}Pengguna ${user_to_delete} berhasil dihapus permanen.${NC}"
    else
        echo ""
        echo -e "${YELLOW}Penghapusan akun dibatalkan.${NC}"
    fi
}

renew_user() {
    clear
	echo -e "${GREEN}=====================[ PERPANJANG AKUN ]=====================${NC}"
	echo -e "${GREEN}=============================================================${NC}"
	echo ""
    if [ ! -s "$USER_DB" ]; then
        echo -e "${RED}Tidak ada pengguna.${NC}"
        return
    fi
    mapfile -t users < "$USER_DB"

    printf "%-4s %-20s %-15s %-15s %-10s\n" "No." "Nama Pengguna" "Hingga" "Sisa" "Status"
	echo -e "${GREEN}=============================================================${NC}"
    
    i=1
    for user_line in "${users[@]}"; do
        username=$(echo "$user_line"|cut -d'|' -f1)
        exp_date=$(echo "$user_line"|cut -d'|' -f3)
        status=$(echo "$user_line"|cut -d'|' -f4)
        [ -z "$status" ] && status="active"

        local color=$GREEN
        if [[ "$status" != "active" ]]; then
            color=$RED
        fi
        
        local sisa_hari_display
        local exp_date_display
        if [[ "$exp_date" == "9999-12-31" ]]; then
            sisa_hari_display="Selamanya"
            exp_date_display="Selamanya"
        else
            sisa_hari_display="$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 )) hari"
            exp_date_display="$exp_date"
        fi
        
        printf "${color}%-4s %-20s %-15s %-15s %-10s${NC}\n" "$i." "$username" "$exp_date_display" "$sisa_hari_display" "$status"
        ((i++))
    done
	echo -e "${GREEN}=============================================================${NC}"
    echo ""

    read -p "Pilih Nomor Pengguna: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Input tidak valid!${NC}"
        return
    fi
    read -p "Tambahan masa aktif (hari, 0 untuk unlimited): " duration
    if ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Input tidak valid!${NC}"
        return
    fi
    
    old_line=$(sed -n "${user_num}p" "$USER_DB")
    username=$(echo "$old_line"|cut -d'|' -f1)
    uuid=$(echo "$old_line"|cut -d'|' -f2)
    
    local new_exp_date
    if [[ "$duration" == "0" ]]; then
        new_exp_date="9999-12-31"
    else
        old_exp_date=$(echo "$old_line"|cut -d'|' -f3)
        if [[ "$old_exp_date" == "9999-12-31" ]]; then
            old_exp_date=$(date +"%Y-%m-%d")
        fi
        new_exp_date=$(date -d "$old_exp_date + $duration days" +"%Y-%m-%d")
    fi

    sed -i "${user_num}s/.*/$username|$uuid|$new_exp_date|active/" "$USER_DB"
    regenerate_config

    if [[ "$new_exp_date" == "9999-12-31" ]]; then
        echo -e "${GREEN}Masa aktif diperbarui menjadi Unlimited. Status diubah menjadi ACTIVE.${NC}"
    else
        echo -e "${GREEN}Masa aktif diperbarui hingga: $new_exp_date. Status diubah menjadi ACTIVE.${NC}"
    fi
}

list_users() {
    while true; do
        clear
        echo -e "${GREEN}=====================[ LIST SEMUA AKUN ]=====================${NC}"
        auto_manage_user_status
        if [ ! -s "$USER_DB" ]; then
            echo "Belum ada pengguna."
            read -n 1 -s -r -p "Tekan apa saja untuk kembali..."
            return
        fi

        mapfile -t users < "$USER_DB"

        printf "%-4s %-20s %-15s %-15s %-10s\n" "No." "Nama Pengguna" "Hingga" "Sisa" "Status"
	    echo -e "${GREEN}=============================================================${NC}"
        
        i=1
        for user_line in "${users[@]}"; do
            username=$(echo "$user_line"|cut -d'|' -f1)
            exp_date=$(echo "$user_line"|cut -d'|' -f3)
            status=$(echo "$user_line"|cut -d'|' -f4)
            [ -z "$status" ] && status="active"

            local color=$GREEN
            if [[ "$status" != "active" ]]; then
                color=$RED
            fi
            
            local sisa_hari_display
            local exp_date_display
            if [[ "$exp_date" == "9999-12-31" ]]; then
                sisa_hari_display="Selamanya"
                exp_date_display="Selamanya"
            else
                sisa_hari_display="$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 )) hari"
                exp_date_display="$exp_date"
            fi
            
            printf "${color}%-4s %-20s %-15s %-15s %-10s${NC}\n" "$i." "$username" "$exp_date_display" "$sisa_hari_display" "$status"
            ((i++))
        done

		echo -e "${GREEN}=============================================================${NC}"
        echo ""
        read -p "Pilih nomor untuk melihat config YAML (Enter untuk kembali): " user_num

        if [ -z "$user_num" ]; then
            return
        fi

        if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
            echo -e "${RED}Pilihan tidak valid!${NC}"; sleep 2; continue
        fi

        local line_content=$(sed -n "${user_num}p" "$USER_DB")
        local username=$(echo "$line_content" | cut -d'|' -f1)
        local uuid=$(echo "$line_content" | cut -d'|' -f2)
        local exp_date=$(echo "$line_content" | cut -d'|' -f3)

        local domain=$(cat "$DOMAIN_FILE")

        clear
        echo -e "Config YAML untuk pengguna: ${YELLOW}${username}${NC}"
		echo -e "${GREEN}=============================================================${NC}"
		echo ""
        cat << EOF
- name: ${username}
  server: ${domain}
  port: 443
  type: vless
  uuid: ${uuid}
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /vlessws
    headers:
      Host: ${domain}
  udp: true
EOF
        echo ""
		echo -e "${GREEN}=============================================================${NC}"
        echo ""
        local exp_message
        if [[ "$exp_date" == "9999-12-31" ]]; then
            exp_message="Masa aktif: Selamanya"
        else
            exp_message="Masa aktif hingga: $exp_date"
        fi
        echo "$exp_message"
        echo ""

        read -n 1 -s -r -p "Tekan tombol apa saja untuk kembali ke daftar pengguna..."
    done
}

auto_manage_user_status() {
    if [ ! -f "$USER_DB" ]; then return; fi
    
    today_epoch=$(date +%s)
    temp_db=$(mktemp)
    changed=false

    while IFS='|' read -r username uuid exp_date status || [[ -n "$username" ]]; do
        if [[ -z "$status" ]]; then
            status="active"
            echo "$username|$uuid|$exp_date|$status" >> "$temp_db"
            changed=true
            continue
        fi

        if [[ "$exp_date" == "9999-12-31" || "$status" == "locked" ]]; then
            echo "$username|$uuid|$exp_date|$status" >> "$temp_db"
            continue
        fi

        exp_epoch=$(date -d "$exp_date" +%s 2>/dev/null || echo 0)
        if [ "$exp_epoch" -lt "$today_epoch" ] && [ "$status" == "active" ]; then
            echo "$username|$uuid|$exp_date|expired" >> "$temp_db"
            changed=true
        else
            echo "$username|$uuid|$exp_date|$status" >> "$temp_db"
        fi
    done < "$USER_DB"

    mv "$temp_db" "$USER_DB"
    if [ "$changed" = true ]; then
        echo "Memperbarui status pengguna & konfigurasi..."
        regenerate_config
    fi
}

manual_toggle_lock() {
    clear
    echo -e "${GREEN}=================[ KUNCI / BUKA KUNCI AKUN ]=================${NC}"
    echo ""
    if [ ! -s "$USER_DB" ]; then
        echo -e "${RED}Tidak ada pengguna.${NC}"; return
    fi
    mapfile -t users < "$USER_DB"
    
    printf "%-4s %-20s %-15s %-15s %-10s\n" "No." "Nama Pengguna" "Hingga" "Sisa" "Status"
	echo -e "${GREEN}=============================================================${NC}"
    
    i=1
    for user_line in "${users[@]}"; do
        username=$(echo "$user_line"|cut -d'|' -f1)
        exp_date=$(echo "$user_line"|cut -d'|' -f3)
        status=$(echo "$user_line"|cut -d'|' -f4)
        [ -z "$status" ] && status="active"

        local color=$GREEN
        if [[ "$status" != "active" ]]; then
            color=$RED
        fi
        
        local sisa_hari_display
        local exp_date_display
        if [[ "$exp_date" == "9999-12-31" ]]; then
            sisa_hari_display="Selamanya"
            exp_date_display="Selamanya"
        else
            sisa_hari_display="$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 )) hari"
            exp_date_display="$exp_date"
        fi
        
        printf "${color}%-4s %-20s %-15s %-15s %-10s${NC}\n" "$i." "$username" "$exp_date_display" "$sisa_hari_display" "$status"
        ((i++))
    done
	echo -e "${GREEN}=============================================================${NC}"
    echo ""

    read -p "Pilih nomor akun untuk diubah statusnya: " user_num
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "${#users[@]}" ]; then
        echo -e "${RED}Pilihan tidak valid!${NC}"; return
    fi

    line="${users[$((user_num-1))]}"
    username=$(echo "$line" | cut -d'|' -f1)
    uuid=$(echo "$line" | cut -d'|' -f2)
    exp_date=$(echo "$line" | cut -d'|' -f3)
    status=$(echo "$line" | cut -d'|' -f4)
    [ -z "$status" ] && status="active"

    if [[ "$status" == "expired" ]]; then
        echo -e "${YELLOW}Akun ini berstatus 'expired'. Harap kelola melalui menu 'Akun Kadaluarsa'.${NC}"
        return
    fi

    new_status=""
    if [[ "$status" == "active" ]]; then
        new_status="locked"
    else
        new_status="active"
    fi

    echo -en "Yakin ingin mengubah status akun ${YELLOW}${username}${NC} dari ${status} menjadi ${new_status}? (y/n): "
    read confirm
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        sed -i "${user_num}s/.*/$username|$uuid|$exp_date|$new_status/" "$USER_DB"
        regenerate_config
        echo -e "${GREEN}Status akun '$username' berhasil diubah menjadi '$new_status'.${NC}"
    else
        echo -e "${YELLOW}Perubahan status dibatalkan.${NC}"
    fi
}

manage_expired_users() {
    while true; do
        clear
        echo -e "${GREEN}================[ AKUN KADALUARSA (EXPIRED) ]================${NC}"
        mapfile -t expired_users < <(grep '|expired$' "$USER_DB")
        
        if [ ${#expired_users[@]} -eq 0 ]; then
            echo -e "${YELLOW}Tidak ada akun yang kadaluwarsa.${NC}"
            echo ""
            read -n 1 -s -r -p "Tekan apa saja untuk kembali..."
            return
        fi

        echo "Daftar akun yang dinonaktifkan (karena kadaluwarsa):"
        i=1
        for user_line in "${expired_users[@]}"; do
            username=$(echo "$user_line" | cut -d'|' -f1)
            exp_date=$(echo "$user_line" | cut -d'|' -f3)
            printf "%-4s %-20s (Kadaluwarsa pada: %s)\n" "$i." "$username" "$exp_date"
            ((i++))
        done
		echo -e "${GREEN}=============================================================${NC}"
        echo ""
        echo "1. Perpanjang Masa Aktif Akun"
        echo "2. Hapus Akun Secara Permanen"
        echo "3. Kembali"
        echo ""
        read -p "Pilih Opsi [1-3]: " choice

        case $choice in
            1)
                read -p "Pilih nomor akun untuk diperpanjang: " user_num
                if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt ${#expired_users[@]} ]; then
                    echo -e "${RED}Pilihan tidak valid!${NC}"; sleep 2; continue
                fi
                read -p "Tambahan masa aktif (hari, 0 untuk unlimited): " duration
                if ! [[ "$duration" =~ ^[0-9]+$ ]]; then
                    echo -e "${RED}Input durasi tidak valid!${NC}"; sleep 2; continue
                fi

                selected_line="${expired_users[$((user_num-1))]}"
                username=$(echo "$selected_line" | cut -d'|' -f1)
                uuid=$(echo "$selected_line" | cut -d'|' -f2)
                
                local new_exp_date
                if [[ "$duration" == "0" ]]; then
                    new_exp_date="9999-12-31"
                else
                    new_exp_date=$(date -d "+$duration days" +"%Y-%m-%d")
                fi

				grep -vF -- "$selected_line" "$USER_DB" > "$USER_DB.tmp"
				echo "${username}|${uuid}|${new_exp_date}|active" >> "$USER_DB.tmp"
				mv "$USER_DB.tmp" "$USER_DB"
                
                if [[ "$new_exp_date" == "9999-12-31" ]]; then
                    echo -e "${GREEN}✓ Akun '${username}' berhasil diaktifkan kembali menjadi Unlimited.${NC}"
                else
                    echo -e "${GREEN}✓ Akun '${username}' berhasil diaktifkan kembali hingga ${new_exp_date}.${NC}"
                fi

                regenerate_config
                sleep 2
                ;;
            2)
                read -p "Pilih nomor akun untuk dihapus permanen: " user_num
                 if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt ${#expired_users[@]} ]; then
                    echo -e "${RED}Pilihan tidak valid!${NC}"; sleep 2; continue
                fi
                selected_line="${expired_users[$((user_num-1))]}"
                username=$(echo "$selected_line" | cut -d'|' -f1)
                
                echo -en "Yakin ingin menghapus permanen akun ${YELLOW}${username}${NC}? (y/n): "
                read confirm
                if [[ "$confirm" =~ ^[Yy]$ ]]; then
                    grep -vF -- "$selected_line" "$USER_DB" > "$USER_DB.tmp" && mv "$USER_DB.tmp" "$USER_DB"
                    echo -e "${GREEN}✓ Akun '${username}' telah dihapus secara permanen.${NC}"
                else
                    echo -e "${YELLOW}Penghapusan dibatalkan.${NC}"
                fi
                sleep 2
                ;;
            3)
                return
                ;;
            *)
                echo -e "${RED}Pilihan salah!${NC}"; sleep 1;;
        esac
    done
}


change_domain() {
    clear
    echo -e "${GREEN}======================[ GANTI DOMAIN ]=======================${NC}"
    local old_domain=$(cat "$DOMAIN_FILE" 2>/dev/null)
    echo -e "Domain saat ini: ${GREEN}$old_domain${NC}"
    echo ""
    read -p "Masukkan domain BARU Anda: " NEW_DOMAIN

    if [ -z "$NEW_DOMAIN" ]; then
        echo -e "${RED}Domain baru kosong! Pembatalan.${NC}"
        return
    fi

    if [ "$NEW_DOMAIN" == "$old_domain" ]; then
        echo -e "${YELLOW}Domain baru sama dengan domain lama. Tidak ada perubahan yang diperlukan.${NC}"
        return
    fi

    echo -e "${GREEN}--- Memulai proses penggantian domain ke $NEW_DOMAIN ---${NC}"
    echo "1. Menghentikan Nginx..."
    systemctl stop nginx || { echo -e "${RED}Gagal menghentikan Nginx.${NC}"; return; }

    echo "2. Memperbarui file domain..."
    echo "$NEW_DOMAIN" > "$DOMAIN_FILE"

    echo "3. Menghapus sertifikat SSL lama..."
    start_spinner
    ~/.acme.sh/acme.sh --uninstall-cert -d "$old_domain" --ecc 2>/dev/null
    ~/.acme.sh/acme.sh --remove -d "$old_domain" --ecc 2>/dev/null
    rm -f "$CERT_FILE" "$KEY_FILE"
    stop_spinner
    echo -e "${GREEN}✓ Sertifikat lama dihapus.${NC}"

    echo "4. Menerbitkan sertifikat SSL baru untuk $NEW_DOMAIN..."
    start_spinner
    if ! ~/.acme.sh/acme.sh --issue -d "$NEW_DOMAIN" --standalone -k ec-256 --force \
        --reloadcmd "systemctl restart xray && systemctl restart nginx"; then
        stop_spinner
        echo -e "${RED}Gagal menerbitkan sertifikat SSL baru! Harap periksa DNS A record Anda.${NC}"
        echo -e "${RED}Mengembalikan ke domain lama (jika memungkinkan) dan me-restart layanan...${NC}"
        echo "$old_domain" > "$DOMAIN_FILE"
        regenerate_config
        return
    fi
    stop_spinner
    echo -e "${GREEN}✓ Sertifikat baru diterbitkan.${NC}"

    echo "5. Menginstal sertifikat baru..."
    start_spinner
    if ! ~/.acme.sh/acme.sh --install-cert -d "$NEW_DOMAIN" --key-file "$KEY_FILE" --cert-file "$CERT_FILE" --ecc; then
        stop_spinner
        echo -e "${RED}Gagal menginstal sertifikat baru ke lokasi Xray!${NC}"
        return
    fi
    stop_spinner
    echo -e "${GREEN}✓ Sertifikat baru terinstal.${NC}"

    chown -R nobody:nogroup /etc/xray/

    echo "6. Memperbarui konfigurasi Xray dan Nginx..."
    regenerate_config

    echo -e "${GREEN}Domain berhasil diganti menjadi ${YELLOW}$NEW_DOMAIN${GREEN} dan semua pengaturan telah diperbarui!${NC}"
}

update_certificate() {
    clear
    echo -e "${GREEN}=================[ PERBARUI SERTIFIKAT SSL ]=================${NC}"
    local domain=$(cat "$DOMAIN_FILE")
    if [ -z "$domain" ]; then
        echo -e "${RED}Domain belum diatur! Harap atur domain terlebih dahulu.${NC}"
        return
    fi

    echo -e "${GREEN}Memperbarui sertifikat SSL untuk domain: ${domain}${NC}"
    echo "Proses ini akan mencoba memperbarui sertifikat SSL menggunakan acme.sh."
    echo "Pastikan DNS A record Anda mengarah ke IP VPS ini."
    echo ""

    echo "Menghentikan Nginx dan Xray..."
    systemctl stop nginx &>/dev/null
    systemctl stop xray &>/dev/null
    echo -e "${GREEN}✓ Layanan dihentikan.${NC}"

    echo "Memulai proses pembaruan sertifikat..."
    start_spinner
    if ~/.acme.sh/acme.sh --issue -d "$domain" --standalone -k ec-256 --force \
        --reloadcmd "systemctl restart xray && systemctl restart nginx" &>/dev/null; then
        stop_spinner
        echo -e "${GREEN}✓ Sertifikat SSL berhasil diperbarui.${NC}"
        if ! ~/.acme.sh/acme.sh --install-cert -d "$domain" --key-file "$KEY_FILE" --cert-file "$CERT_FILE" --ecc &>/dev/null; then
            echo -e "${RED}Gagal menginstal sertifikat yang baru diperbarui ke lokasi Xray!${NC}"
        else
            echo -e "${GREEN}✓ Sertifikat baru berhasil diinstal ke lokasi Xray.${NC}"
        fi
        chown -R nobody:nogroup /etc/xray/
        regenerate_config
        echo -e "${GREEN}Proses pembaruan sertifikat selesai.${NC}"
    else
        stop_spinner
        echo -e "${RED}Gagal memperbarui sertifikat SSL!${NC}"
        echo -e "${RED}Harap periksa log acme.sh untuk detail lebih lanjut atau pastikan DNS A record sudah benar.${NC}"
        echo -e "${YELLOW}Mencoba me-restart layanan yang dihentikan...${NC}"
        systemctl start nginx &>/dev/null
        systemctl start xray &>/dev/null
        regenerate_config
    fi
}

run_installation() {
    clear
    echo -e "${GREEN}====================[ MEMULAI INSTALASI ]====================${NC}"
	echo ""
    read -p "Masukkan domain Anda: " DOMAIN
    if [ -z "$DOMAIN" ]; then
        echo "${RED}Domain kosong!${NC}"
        exit 1
    fi
    mkdir -p /etc/xray /usr/local/etc/xray "$INSTALL_DIR"
    echo "$DOMAIN" > "$DOMAIN_FILE"
    echo "Menyalin skrip ke $INSTALL_DIR..."
    cp "$SCRIPT_REAL_DIR"/*.sh "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR"/*.sh
    ln -sf "$INSTALL_DIR/main.sh" /usr/local/bin/menu

    echo "=> Menginstal dependensi..."
    start_spinner
    apt-get update -y &>/dev/null
    apt-get --reinstall --fix-missing install -y sudo dpkg psmisc socat jq ruby tmux \
	nmap bzip2 gzip coreutils wget curl screen rsyslog iftop htop net-tools zip unzip \
	vim nano sed gnupg gnupg1 bc apt-transport-https build-essential gcc g++ automake \
	make autoconf perl m4 dos2unix dropbear libreadline-dev zlib1g-dev libssl-dev \
	dirmngr libxml-parser-perl git lsof nftables openssl easy-rsa fail2ban vnstat python3 \
	libsqlite3-dev cron bash-completion xz-utils gnupg2 dnsutils lsb-release chrony nginx &>/dev/null
    stop_spinner
    echo -e "${GREEN}✓ Dependensi terinstal.${NC}"

    echo "=> Menginstal lolcat..."
    start_spinner
    gem install lolcat &>/dev/null
    stop_spinner
    echo -e "${GREEN}✓ lolcat terinstal.${NC}"

    echo "=> Menginstal rclone..."
    start_spinner
    curl https://rclone.org/install.sh | bash &>/dev/null
    stop_spinner
    echo -e "${GREEN}✓ rclone terinstal.${NC}"

    echo "=> Mengatur IPv6 & Waktu..."
    echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6
    sed -i '/net.ipv6.conf.all.disable_ipv6/d' /etc/sysctl.conf
    echo "net.ipv6.conf.all.disable_ipv6 = 1" >> /etc/sysctl.conf
    configure_sysctl
    sysctl -p
    timedatectl set-timezone Asia/Jakarta
    echo -e "${GREEN}✓ Pengaturan sistem dasar selesai.${NC}"

    local total_ram_mb=$(free -m | awk 'NR==2{print $2}')
    local swap_size_mb=0
    local swap_path="/swapfile"

    echo "=> Memeriksa RAM untuk konfigurasi swap..."
    if swapon -s | grep -q "$swap_path"; then
        echo -e "${YELLOW}  Swap file '$swap_path' sudah aktif. Melewatkan pembuatan swap.${NC}"
    else
        if [ "$total_ram_mb" -lt 3072 ]; then
            swap_size_mb=1024
            echo "  RAM terdeteksi ${total_ram_mb}MB. Menambahkan swap ${swap_size_mb}MB."

            echo "  Membuat swap file sebesar ${swap_size_mb}MB..."
            start_spinner
            fallocate -l "${swap_size_mb}M" "$swap_path" &>/dev/null
            chmod 600 "$swap_path" &>/dev/null
            mkswap "$swap_path" &>/dev/null
            swapon "$swap_path" &>/dev/null
            stop_spinner

            if [ $? -eq 0 ]; then
                if ! grep -q "$swap_path" /etc/fstab; then
                    echo "$swap_path none swap sw 0 0" >> /etc/fstab
                    echo -e "${GREEN}  ✓ Swap file berhasil dibuat dan diaktifkan, ditambahkan ke fstab.${NC}"
                else
                    echo -e "${GREEN}  ✓ Swap file berhasil dibuat dan diaktifkan (sudah ada di fstab).${NC}"
                fi
            else
                echo -e "${RED}  Gagal membuat swap file.${NC}"
                rm -f "$swap_path"
            fi
        else
            echo -e "${YELLOW}  RAM terdeteksi ${total_ram_mb}MB (>= 3GB). Pembuatan swap dilewati.${NC}"
        fi
    fi

    echo "=> Menginstal Xray-core..."
    start_spinner
    curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh | bash &>/dev/null
    stop_spinner
    echo -e "${GREEN}✓ Xray-core terinstal.${NC}"

    echo "=> Membuat sertifikat SSL..."
    systemctl stop nginx
    start_spinner
    curl https://get.acme.sh | sh &>/dev/null
    ~/.acme.sh/acme.sh --set-default-ca --server letsencrypt &>/dev/null
    ~/.acme.sh/acme.sh --issue -d "$DOMAIN" --standalone -k ec-256 --force \
        --reloadcmd "systemctl restart xray && systemctl restart nginx" &>/dev/null
    ~/.acme.sh/acme.sh --install-cert -d "$DOMAIN" --key-file "$KEY_FILE" --cert-file "$CERT_FILE" --ecc &>/dev/null
    stop_spinner

    if [[ ! -f "$CERT_FILE" || ! -f "$KEY_FILE" ]]; then
        echo -e "${RED}Gagal membuat SSL! Pastikan DNS A record sudah mengarah ke IP VPS ini.${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ Sertifikat SSL berhasil dibuat.${NC}"

    echo "=> Konfigurasi akhir..."
    regenerate_config
    (crontab -l 2>/dev/null; echo "0 3 * * * $MAIN_SCRIPT_PATH --automanage")|crontab -
    (crontab -l 2>/dev/null; echo "0 4 */2 * * /sbin/reboot")|crontab -
    echo -e "${GREEN}Instalasi selesai! Jalankan 'menu' untuk membuka panel.${NC}"

    echo "=> Membersihkan direktori kerja awal..."
    rm -rf "$SCRIPT_REAL_DIR"
}

install_update_helium() {
    clear
    echo -e "${GREEN}=================[ INSTALASI/UPDATE HELIUM ]=================${NC}"
    echo "Mengunduh dan menginstal Helium..."
    start_spinner
    if rm -rf /usr/local/sbin/helium && wget -q -O /usr/local/sbin/helium https://raw.githubusercontent.com/abidarwish/helium/main/helium.sh && chmod +x /usr/local/sbin/helium; then
        stop_spinner
        echo -e "${GREEN}✓ Helium terinstal. Menjalankan...${NC}"
        sleep 2
        helium
    else
        stop_spinner
        echo -e "${RED}Gagal instal Helium.${NC}"
    fi
}

run_helium() {
    clear
    if command -v helium &> /dev/null; then
        echo -e "${GREEN}Menjalankan Helium...${NC}"
        helium
    else
        echo -e "${RED}Helium tidak ditemukan.${NC}"
    fi
}

menu_helium() {
    clear
    while true; do
	echo -e "${GREEN}=======================[ MENU HELIUM ]=======================${NC}"
	echo ""
        echo "1. Install/Update & Jalankan"
        echo "2. Jalankan (jika terinstal)"
        echo "3. Kembali"
        echo ""
		echo -e "${GREEN}=============================================================${NC}"
		echo ""
        read -p "Pilih [1-3]: " choice
        case $choice in
            1) install_update_helium; break;;
            2) run_helium; break;;
            3) break;;
            *) echo -e "${RED}Pilihan salah!${NC}"; sleep 1; clear;;
        esac
    done
}

display_info_panel() {
    os_info=$(lsb_release -ds)
    cpu_cores=$(nproc)
    ram_info=$(free -m|awk 'NR==2{printf "%.2f/%.2f GB", $3/1024, $2/1024}')
    uptime_info=$(uptime -p)
    ip_info=$(curl -s 'http://ip-api.com/json/')
    vps_ip=$(echo "$ip_info"|jq -r '.query')
    vps_city=$(echo "$ip_info"|jq -r '.city')
    vps_domain=$(cat "$DOMAIN_FILE")
    
    total_users=0; active_users=0; locked_users=0; expired_users=0
    if [ -f "$USER_DB" ]; then
        total_users=$(wc -l <"$USER_DB"|xargs)
        active_users=0
        locked_users=0
        expired_users=0
        while IFS='|' read -r _ _ _ status; do
            case "$status" in
                "active"|"") ((active_users++));;
                "locked")   ((locked_users++));;
                "expired")  ((expired_users++));;
            esac
        done < "$USER_DB"
    fi

    if systemctl is-active --quiet xray; then
        xray_status="${GREEN}ON${NC}"
    else
        xray_status="${RED}OFF${NC}"
    fi
    if systemctl is-active --quiet nginx; then
        nginx_status="${GREEN}ON${NC}"
    else
        nginx_status="${RED}OFF${NC}"
    fi
    current_date=$(date +"%A, %d %B %Y")
    current_time=$(date +"%T WIB")
	usage_today=$(vnstat -d | grep "$(date +"%Y-%m-%d")" | awk '{print $5, $6}')
    if [[ "$usage_today" =~ "GiB" ]]; then
        usage_today=$(echo "$usage_today" | sed 's/GiB/GB/')
    fi
    [ -z "$usage_today" ] && usage_today="Data Belum Tersedia"

    usage_yesterday=$(vnstat -d | grep "$(date -d "yesterday" +"%Y-%m-%d")" | awk '{print $5, $6}')
    if [[ "$usage_yesterday" =~ "GiB" ]]; then
        usage_yesterday=$(echo "$usage_yesterday" | sed 's/GiB/GB/')
    fi
    [ -z "$usage_yesterday" ] && usage_yesterday="Data Belum Tersedia"

	usage_this_month=$(vnstat -m | grep "$(date +"%Y-%m")" | awk '{print $5, $6}')
    if [[ "$usage_this_month" =~ "GiB" ]]; then
        usage_this_month=$(echo "$usage_this_month" | sed 's/GiB/GB/')
    fi
    [ -z "$usage_this_month" ] && usage_this_month="Data Belum Tersedia"

    clear
    echo -e "${GREEN}=============[ MANAJEMEN VLESS A2OS ]==============${NC}"
    printf "%-12s: %s\n" "OS" "$os_info"
    printf "%-12s: %s\n" "CPU Core" "$cpu_cores Core"
    printf "%-12s: %s\n" "RAM" "$ram_info"
    printf "%-12s: %s\n" "Domain" "$vps_domain"
    printf "%-12s: %s\n" "IP VPS" "$vps_ip"
    printf "%-12s: %s\n" "City" "$vps_city"
    printf "%-12s: %s\n" "Uptime" "$uptime_info"
    printf "%-12s: %s\n" "Date" "$current_date"
    printf "%-12s: %s\n" "Time" "$current_time"
    echo -e "${GREEN}===================================================${NC}"
    status_line="Xray: [${xray_status}] | Nginx: [${nginx_status}]"
    clean_line_status=$(echo -e "$status_line" | sed 's/\x1b\[[0-9;]*m//g')
    padding_status=$(((51 - ${#clean_line_status}) / 2))
    printf "%*s" $padding_status ""
    echo -e "$status_line"
    echo -e "${GREEN}================[ PENGGUNAAN DATA ]================${NC}"
    printf "%-12s: %s\n" "Hari Ini" "$usage_today"
    printf "%-12s: %s\n" "Kemarin" "$usage_yesterday"
    printf "%-12s: %s\n" "Bulan Ini" "$usage_this_month"
    echo -e "${GREEN}===================[ TOTAL AKUN ]==================${NC}"
	echo ""
    akun_line="Total: $total_users | ${GREEN}Aktif: $active_users${NC} | ${RED}Terkunci: $locked_users${NC} | ${YELLOW}Expired: $expired_users${NC}"
    clean_akun_line=$(echo -e "$akun_line" | sed 's/\x1b\[[0-9;]*m//g')
    padding_akun=$(((51 - ${#clean_akun_line}) / 2))
    printf "%*s" $padding_akun ""
    echo -e "$akun_line"
	echo ""
}

menu_vless() {
    while true; do
        clear
		echo -e "${GREEN}===================[ MENU VLESS ]====================${NC}"
        printf "${GREEN}│ %-48s │${NC}\n" ""
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    1. Buat Akun"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    2. Hapus Akun"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    3. Perpanjang Akun"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    4. List Akun"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    5. Lock/Unlock Akun"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    6. Akun Kadaluarsa"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    7. Kembali ke Menu Utama"
        printf "${GREEN}│ %-48s │${NC}\n" ""
		echo -e "${GREEN}===================================================${NC}"
		echo ""
		printf "${GREEN}Pilih opsi [1-7]: ${NC}"
		read choice
        
        case $choice in
            1) add_user;;
            2) delete_user;;
            3) renew_user;;
            4) list_users;;
            5) manual_toggle_lock;;
            6) manage_expired_users;;
            7) break;;
            *) echo -e "${RED}Pilihan salah!${NC}";;
        esac
        echo ""
        read -n 1 -s -r -p "Tekan apa saja untuk lanjut..."
    done
}

main_menu() {
    while true; do
        auto_manage_user_status
        display_info_panel

		echo -e "${GREEN}===================[ MENU UTAMA ]==================${NC}"
        printf "${GREEN}│ %-48s │${NC}\n" ""
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    1. Menu VLESS"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    2. Backup Data"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    3. Restore Data"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    4. Menu Helium"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    5. Ganti Domain"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    6. Perbarui Sertifikat SSL"
        printf "${GREEN}│${NC} %-48s ${GREEN}│${NC}\n" "    7. Keluar"
        printf "${GREEN}│ %-48s │${NC}\n" ""
	    echo -e "${GREEN}==============[ MANAJEMEN VLESS A2OS ]=============${NC}"
		echo ""
		echo -e "${GREEN}===================================================${NC}"
		printf "${GREEN}Pilih opsi [1-7]: ${NC}"
		read choice
		echo -e "${GREEN}===================================================${NC}"

        case $choice in
            1) menu_vless;;
            2) "$INSTALL_DIR/backup.sh";;
            3) "$INSTALL_DIR/restore.sh";;
            4) menu_helium;;
            5) change_domain;;
            6) update_certificate;;
            7) exit 0;;
            *) echo -e "${RED}Pilihan salah!${NC}";;
        esac
        echo ""
        read -n 1 -s -r -p "Tekan apa saja untuk lanjut..."
    done
}

check_root
if [[ "$1" == "--automanage" ]]; then
    auto_manage_user_status
    exit 0
fi
if [ ! -f "$CONFIG_FILE" ]; then
    run_installation
fi
main_menu