#!/bin/bash

#================================================================================================
# FILE KONFIGURASI BERSAMA (Versi VLESS WS)
#================================================================================================

GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[0;33m"
NC="\033[0m"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

USER_DB="/etc/xray/user_database.txt"
CONFIG_FILE="/usr/local/etc/xray/config.json"
NGINX_CONF="/etc/nginx/conf.d/xray.conf"
CERT_FILE="/etc/xray/xray.crt"
KEY_FILE="/etc/xray/xray.key"
DOMAIN_FILE="/etc/xray/domain.txt"
RCLONE_CONF="/etc/xray/rclone.conf"

INSTALL_DIR="/usr/local/bin/vless-manager"
MAIN_SCRIPT_PATH="${INSTALL_DIR}/main.sh"

check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}Skrip ini harus dijalankan sebagai root${NC}"
        exit 1
    fi
}

regenerate_config() {
    local domain
    domain=$(cat "$DOMAIN_FILE")
    local clients_json=""
    if [ -s "$USER_DB" ]; then
        # Membaca format baru: nama_pengguna|uuid|exp_date|status
        while IFS='|' read -r username uuid exp_date status || [[ -n "$username" ]]; do
            if [[ -z "$status" || "$status" == "active" ]]; then
                # Membuat JSON untuk VLESS menggunakan UUID dan nama pengguna sebagai email/label
                clients_json+="{ \"id\": \"$uuid\", \"email\": \"$username\" },"
            fi
        done < "$USER_DB"
        clients_json=${clients_json%,}
    fi

    cat << EOF > "$CONFIG_FILE"
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": 443,
      "protocol": "vless",
      "settings": {
        "clients": [ $clients_json ],
        "decryption": "none",
        "fallbacks": [
          {
            "dest": 8080,
            "xver": 1
          }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {
          "certificates": [
            {
              "certificateFile": "$CERT_FILE",
              "keyFile": "$KEY_FILE"
            }
          ]
        },
        "wsSettings": {
          "path": "/vlessws"
        }
      }
    }
  ],
  "outbounds": [{ "protocol": "freedom" }]
}
EOF

    cat << EOF > "$NGINX_CONF"
server {
    listen 127.0.0.1:8080;
    server_name $domain;
    root /var/www/html;
    index index.html index.htm;

    location / {
        try_files \$uri \$uri/ =404;
    }
}
EOF

    chown -R nobody:nogroup /etc/xray/

    if [[ -f "$CERT_FILE" && -f "$KEY_FILE" ]]; then
        echo "Me-restart layanan Xray dan Nginx..."
        systemctl restart xray
        if systemctl is-active --quiet xray; then
            echo -e "${GREEN}✓ Xray berhasil di-restart.${NC}"
        else
            echo -e "${RED}Xray gagal restart! Periksa 'systemctl status xray' untuk detail.${NC}"
        fi

        systemctl restart nginx
        if systemctl is-active --quiet nginx; then
            echo -e "${GREEN}✓ Nginx berhasil di-restart.${NC}"
        else
            echo -e "${RED}Nginx gagal restart! Periksa 'systemctl status nginx' untuk detail.${NC}"
        fi
    else
        echo -e "${YELLOW}Sertifikat SSL belum tersedia. Nginx tidak direstart.${NC}"
    fi
}


setup_rclone() {
    if [ -f "$RCLONE_CONF" ]; then return 0; fi
    clear
	echo -e "${YELLOW}===========[ PENGATURAN AWAL BACKUP/RESTORE (RCLONE) ]===========${NC}"
	echo ""
    echo "Anda akan diarahkan ke setup interaktif Rclone untuk menghubungkan akun cloud."
    read -n 1 -s -r -p "Tekan tombol apa saja untuk memulai 'rclone config'..."
    rclone config
    echo -e "\n${GREEN}Setup interaktif Rclone Selesai.${NC}"
	echo -e "${YELLOW}=================================================================${NC}"
	echo ""
    echo "Mendeteksi remote yang tersedia..."
    mapfile -t remotes < <(rclone listremotes | sed 's/://')
    local rclone_remote=""
    if [ ${#remotes[@]} -eq 0 ]; then
        echo -e "${RED}Tidak ada remote Rclone yang terdeteksi. Setup gagal.${NC}"
        return 1
    elif [ ${#remotes[@]} -eq 1 ]; then
        rclone_remote="${remotes[0]}"
        echo -e "${GREEN}Satu remote terdeteksi: ${YELLOW}$rclone_remote${GREEN}. Remote ini akan digunakan secara otomatis.${NC}"
    else
        echo "Beberapa remote terdeteksi. Silakan pilih satu untuk digunakan:"
        local i=1
        for remote in "${remotes[@]}"; do echo "$i. $remote"; ((i++)); done
        read -p "Pilih nomor remote [1-${#remotes[@]}]: " remote_num
        if ! [[ "$remote_num" =~ ^[0-9]+$ ]] || [ "$remote_num" -lt 1 ] || [ "$remote_num" -gt "${#remotes[@]}" ]; then
            echo -e "${RED}Pilihan tidak valid! Setup gagal.${NC}"; return 1
        fi
        rclone_remote="${remotes[$((remote_num-1))]}"
    fi
    echo -e "Menggunakan remote: ${YELLOW}$rclone_remote${NC}"
    read -p "Masukkan nama FOLDER untuk backup di remote '$rclone_remote' (contoh: xray_backup): " rclone_path
    if [ -z "$rclone_path" ]; then echo -e "${RED}Nama folder tidak boleh kosong! Pengaturan backup gagal.${NC}"; return 1; fi
    echo "RCLONE_REMOTE=$rclone_remote" > "$RCLONE_CONF"
    echo "RCLONE_PATH=$rclone_path" >> "$RCLONE_CONF"
    echo -e "${GREEN}Konfigurasi backup untuk skrip ini berhasil disimpan!${NC}"
    sleep 2
    return 0
}

configure_sysctl() {
    echo "=> Menambahkan konfigurasi sysctl..."
    cat << EOF >> /etc/sysctl.conf
fs.file-max = 500000
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.netdev_max_backlog = 250000
net.core.somaxconn = 4096
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.ip_local_port_range = 10000 65000
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mem = 25600 51200 102400
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.core.rmem_max = 4000000
net.ipv4.tcp_mtu_probing = 1
net.ipv4.ip_forward = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
}